This time I still got two versions uploaded.

The version "Lab6" is the one totally works and I wish you to GRADE this one.

The version "Lab6 with topmodule" is the one I tried hard on it but still had some problems. I got the schematic and  waveform correctly on this version, but no I/O planning. 
This version is just one that I want let you know I tried on it.